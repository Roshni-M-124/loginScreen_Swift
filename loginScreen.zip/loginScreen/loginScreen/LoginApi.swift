//
//  LoginApi.swift
//  loginScreen
//
//  Created by Mobicip on 27/05/26.
//

import UIKit
import CryptoKit

struct ServerResponse: Decodable {
    let mwsResponse: MWSContent
}

struct MWSContent: Decodable {
    let managed_users: [Child]?
    let status: ResponseStatus
}

struct ResponseStatus: Decodable {
    let code: String
    let message: String
}

struct Child: Decodable {
    let name: String
    let age: Int
    let thumbnail: String?
}

func md5Hash(_ string: String) -> String {
    guard let data = string.data(using: .utf8) else { return "" }
    let digest = Insecure.MD5.hash(data: data)
    return digest.map { String(format: "%02hhx", $0) }.joined()
}

class LoginApi {
    
    func loginAndFetchChildren(email: String, password: String) async -> ( Bool,String,String,[Child]) {
        let clientKey = "eQmqIhqfIeNs0OX6avY5YpauB"
        let token = "NO-TOKEN"
        
        let apiDetails: [String: Any] = ["version": "2.3", "app_version": "7.0"]
        let clientDetails : [String: Any] = ["version": "2.2", "identity": "21V21B337GMX2", "session_hash": "de951cc9-0a2e-41fd-918d-b2f55c09d780"]
        let sessionDetails: [String: Any] = ["token": token]
        let userDetails: [String: Any] = [
            "timezone": "Asia/Kolkata",
            "email": email,
            "password": md5Hash(password)
        ]
        
        let body: [String: Any] = [
            "api": apiDetails,
            "Client": clientDetails,
            "User": userDetails,
            "Session": sessionDetails
        ]
        
        let innerRequestBody: [String: Any] = ["Request": body]
        
        guard let innerJsonData = try? JSONSerialization.data(withJSONObject: innerRequestBody, options: .withoutEscapingSlashes),
              let innerRequestString = String(data: innerJsonData, encoding: .utf8) else {
            return (false,"","Request is malformed",[])
        }
        
        let hmacInput = token + innerRequestString + clientKey
        let hmacKey = SymmetricKey(data: Data(token.utf8))
        let signature = HMAC<SHA256>.authenticationCode(for: Data(hmacInput.utf8), using: hmacKey)
        let checksum = signature.map { String(format: "%02x", $0) }.joined()
        
        let dict: [String: Any] = [
            "mwsRequest": [
                "String": ["Request": body],
                "Checksum": checksum
            ]
        ]
        
        guard let finalJsonData = try? JSONSerialization.data(withJSONObject: dict),
              let url = URL(string: "https://webd.prgr.in/api/v2/login") else {
            return (false,"","URL doesn't exist",[])
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.httpBody = finalJsonData
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                return (false,"","Request Unsuccessful", [])
            }
            
            let Response = String(data: data, encoding: .utf8)
            print(Response ?? "")
            
            let decoder = JSONDecoder()
            let decodedResponse = try decoder.decode(ServerResponse.self, from: data)
            
            if decodedResponse.mwsResponse.status.code == "000" {
                return (true, decodedResponse.mwsResponse.status.code,decodedResponse.mwsResponse.status.message,decodedResponse.mwsResponse.managed_users ?? [])
            } else {
                print("Server validation failed code: \(decodedResponse.mwsResponse.status.code)")
                return (false,decodedResponse.mwsResponse.status.code,decodedResponse.mwsResponse.status.message, [])
            }
            
        } catch {
            print(" Network or Parsing error: \(error.localizedDescription)")
            return (false,"","Network Error", [])
        }
    }
}
