//
//  HomeViewController.swift
//  loginScreen
//
//  Created by Mobicip on 14/04/26.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{

    let tableView: UITableView = {
        let table = UITableView()
        table.register(ChildCell.nib(), forCellReuseIdentifier: ChildCell.identifier)
        table.rowHeight = 75
        table.bounces = false
        table.showsVerticalScrollIndicator = false
        return table
    }()

    lazy var logoutButton: UIBarButtonItem = {
        let button = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(logoutTapped))
        return button
    }()
    
    private let managedChildren: [Child]

    var imageCache: [URL: UIImage] = [:]
    var runningTask: [URL: [(UIImage?) -> Void]] = [:]

    init(children: [Child]) {
        self.managedChildren = children
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        view.backgroundColor = .white

        tableView.delegate = self
        tableView.dataSource = self

        view.addSubview(tableView)
        tableView.frame = view.bounds
        title = "Managed Profiles"
        navigationItem.rightBarButtonItem = logoutButton
    }
    
    @objc func logoutTapped() {
        Keychain.shared.deleteCredentials()
        navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return managedChildren.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChildCell", for: indexPath) as! ChildCell
        let child = managedChildren[indexPath.row]
        cell.configure(name: child.name,age: child.age, image: nil)
        
        guard let thumbnailString = child.thumbnail,
              let url = URL(string: thumbnailString),
              !thumbnailString.isEmpty,
              thumbnailString != "<null>" else {
            return cell
        }
        
        cell.currentImageURL = url
        
        if let image = imageCache[url] {
            cell.configure(name: child.name,age: child.age, image: image)
        } else {
            fetchImage(from: url) { [weak cell] image in
                guard let cell = cell, cell.currentImageURL == url else { return }
                cell.configure(name: child.name,age: child.age, image: image)
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func fetchImage(from url: URL, completion: @escaping (UIImage?) -> Void) {
        
        if let cachedImage = imageCache[url] {
            completion(cachedImage)
            return
        }
        
        if runningTask[url] != nil {
            runningTask[url]?.append(completion)
            return
        }
        
        runningTask[url] = [completion]
        let task = URLSession.shared.downloadTask(with: url) { [weak self] localURL, _, error in
            if let error = error {
                print("Image Download Error: \(error.localizedDescription)")
                DispatchQueue.main.async { self?.runningTask.removeValue(forKey: url) }
                return
            }
            
            do {
                guard let localURL = localURL else {
                    DispatchQueue.main.async { self?.runningTask.removeValue(forKey: url) }
                    return
                }
                let data = try Data(contentsOf: localURL)
                let image = UIImage(data: data)
                
                DispatchQueue.main.async {
                    self?.imageCache[url] = image
                    self?.runningTask[url]?.forEach { $0(image) }
                    self?.runningTask.removeValue(forKey: url)
                }
            } catch {
                print("Error: \(error.localizedDescription)")
                DispatchQueue.main.async { self?.runningTask.removeValue(forKey: url) }
            }
        }
        task.resume()
    }
}
