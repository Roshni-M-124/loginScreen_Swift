//
//  HomeViewController.swift
//  loginScreen
//
//  Created by Mobicip on 14/04/26.
//

import UIKit

// Data

nonisolated enum Section {
    case main
}

nonisolated struct Fruit: Hashable {
    let id = UUID()
    let title: String
    let price: String
    let imageURL: URL
    
}

nonisolated enum Item: Hashable {
    case fruit(Fruit)
    case price(Fruit)
}

// ViewController

class HomeViewController: UIViewController,
                          UITableViewDelegate,
                          UITableViewDataSourcePrefetching {

    let tableView: UITableView = {
        let table = UITableView()
        table.register(FruitCell.self, forCellReuseIdentifier: "FruitCell")
        table.rowHeight = UITableView.automaticDimension
        table.estimatedRowHeight = 80
        return table
    }()

    var dataSource: UITableViewDiffableDataSource<Section, Item>!

    lazy var logoutButton: UIBarButtonItem = {
        let button = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(logoutTapped))
        return button
    }()
    
    var fruits: [Fruit] = [
        Fruit(title: "Apple", price: "₹120/kg", imageURL: URL(string: "https://cdn.pixabay.com/photo/2016/09/29/08/33/apple-1702316_1280.jpg")!),
        Fruit(title: "Banana", price: "₹60/kg", imageURL:  URL(string: "https://img.freepik.com/free-vector/vector-ripe-yellow-banana-bunch-isolated-white-background_1284-45456.jpg?semt=ais_hybrid&w=740&q=80")!),
        Fruit(title: "Orange", price: "₹80/kg", imageURL: URL(string:"https://img.freepik.com/free-photo/fresh-orange-isolated-white-background_93675-131671.jpg")!),
        Fruit(title: "Mango", price: "₹150/kg", imageURL: URL(string:"https://i.pinimg.com/474x/6d/c0/13/6dc0138f240932023a22f1b4828ed0fd.jpg")!),
        Fruit(title: "Grapes", price: "₹90/kg", imageURL:  URL(string:"https://www.shutterstock.com/image-photo/red-grapes-hanging-on-vine-600nw-2475929273.jpg")!),
        Fruit(title: "Pineapple", price: "₹70/kg", imageURL: URL(string:"https://i.pinimg.com/474x/ca/e0/88/cae0888867e43b432a5e8ffe033a234d.jpg")!),
        Fruit(title: "Papaya", price: "₹50/kg", imageURL: URL(string:"https://t3.ftcdn.net/jpg/01/77/22/44/360_F_177224431_6S50Gr64wFWjkDHBGXq7PkaG5kcrgEgd.jpg")!),
        Fruit(title: "Watermelon", price: "₹40/kg", imageURL: URL(string:"https://img.freepik.com/free-photo/green-striped-ripe-watermelon-with-slice-cross-section-isolated-white-background-with-copy-space-text-images-special-kind-berry-sweet-pink-flesh-with-black-seeds-side-view_639032-1254.jpg?semt=ais_hybrid&w=740&q=80")!),
        Fruit(title: "Guava", price: "₹55/kg", imageURL: URL(string:"https://i.pinimg.com/736x/0c/7e/dc/0c7edcc7c166411876163bd3e75d8b3b.jpg")!),
        Fruit(title: "Strawberry", price: "₹200/kg", imageURL:  URL(string:"https://img.freepik.com/free-photo/strawberry-isolated-white-background_1232-1974.jpg?semt=ais_hybrid&w=740&q=80")!),
        Fruit(title: "Blueberry", price: "₹350/kg", imageURL: URL(string:"https://img.freepik.com/free-vector/fresh-blueberries-with-water-drops-green-leaves-white-background-realistic-vector-illustration_1284-77363.jpg?semt=ais_hybrid&w=740&q=80")!),
        Fruit(title: "Kiwi", price: "₹180/kg", imageURL: URL(string:"https://cdn.britannica.com/45/126445-050-4C0FA9F6/Kiwi-fruit.jpg")!),
        Fruit(title: "Pomegranate", price: "₹140/kg", imageURL: URL(string:"https://img.freepik.com/free-vector/pomegranate-realistic-concept-with-organic-food-symbols-vector-illustration_1284-75800.jpg?semt=ais_hybrid&w=740&q=80")!),
        Fruit(title: "Dragon Fruit", price: "₹220/kg", imageURL:
                URL(string:"https://images.unsplash.com/photo-1698546690393-45482eb06942?fm=jpg&q=60&w=3000&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8ZHJhZ29uJTIwZnJ1aXR8ZW58MHx8MHx8fDA%3D")!),
        Fruit(title: "Lychee", price: "₹160/kg", imageURL:  URL(string:"https://cdn.britannica.com/18/176518-050-5AB1E61D/lychee-fruits-Southeast-Asia.jpg")!),
        Fruit(title: "Peach", price: "₹130/kg", imageURL: URL(string:"https://img.freepik.com/premium-photo/peach-fruit-isolated_809796-9569.jpg?semt=ais_hybrid&w=740&q=80")!),
        Fruit(title: "Pear", price: "₹110/kg", imageURL:  URL(string:"https://img.freepik.com/free-vector/vintage-pear-illustration_53876-112720.jpg")!),
        Fruit(title: "Plum", price: "₹125/kg", imageURL:  URL(string:"https://media.istockphoto.com/id/687478414/photo/red-cherry-plum-with-green-leaves-isolated-on-white-background.jpg?s=612x612&w=0&k=20&c=vje7nFHGnWl-cHDA8wP_UZHryRT5LkAFwn7_8qKtiyc=")!),
        Fruit(title: "Cherry", price: "₹300/kg", imageURL: URL(string:"https://www.shutterstock.com/image-vector/two-cherries-isolated-on-white-600nw-2425033511.jpg")!),
        Fruit(title: "Custard Apple", price: "₹90/kg", imageURL:  URL(string:"https://cdn.britannica.com/95/126995-050-101B8B8D/Sweetsop.jpg")!)
    ]

    var imageCache: [URL : UIImage] = [:]
    var expandedFruitID: UUID? = nil
    var currentPriceItem: Item? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white

        tableView.delegate = self
        tableView.prefetchDataSource = self

        view.addSubview(tableView)
        tableView.frame = view.bounds
        title = "Fruits"
        navigationItem.rightBarButtonItem = logoutButton
        configureDataSource()
        applyInitialSnapshot()
    }
    
    @objc func logoutTapped(){
        Keychain.shared.deleteCredentials()
        navigationController?.popViewController(animated: true)
    }
}

// DataSource

extension HomeViewController {

    func configureDataSource() {

        dataSource = UITableViewDiffableDataSource<Section, Item>(
            tableView: tableView
        ) { [weak self] tableView, indexPath, item in

            switch item {

            case .fruit(let fruit):

                let cell = tableView.dequeueReusableCell(withIdentifier: "FruitCell",for: indexPath) as! FruitCell
                cell.currentImageURL = fruit.imageURL
                let url = fruit.imageURL
                cell.configure(title:fruit.title, image: nil)
                
                if let image = self?.imageCache[url] {
                    cell.configure(title: fruit.title, image: image)
                } else {
                    
                    self?.fetchImage(from: url){ [weak cell] image in
                        guard let cell = cell, cell.currentImageURL == url else { return }
                        cell.configure(title: fruit.title, image: self?.imageCache[url])
                    }
                }

                return cell

            case .price(let fruit):

                let cell = UITableViewCell()
                cell.textLabel?.text = "Price: \(fruit.price)"
                cell.textLabel?.textColor = .gray
                return cell
            }
        }
    }
}

//Snapshot

extension HomeViewController {

    func applyInitialSnapshot() {

        var snapshot = NSDiffableDataSourceSnapshot<Section, Item>()
        snapshot.appendSections([.main])
        let items = fruits.map { Item.fruit($0) }
        snapshot.appendItems(items)
        dataSource.apply(snapshot, animatingDifferences: false)
    }

    func updateDataSource(_ indexPath: IndexPath) {

        guard let item = dataSource.itemIdentifier(for: indexPath) else { return }
        var snapshot = dataSource.snapshot()

        switch item {

        case .fruit(let fruit):
            
            if expandedFruitID == fruit.id {

                if let priceItem = currentPriceItem {
                    snapshot.deleteItems([priceItem])
                    currentPriceItem = nil
                }

                expandedFruitID = nil
            }
        
            // New fruit tapped
            else {
                // Remove old price row
                if let priceItem = currentPriceItem {
                    snapshot.deleteItems([priceItem])
                }

                // Insert new price row
                let newPriceItem = Item.price(fruit)
                snapshot.insertItems([newPriceItem], afterItem: item)
                currentPriceItem = newPriceItem
                expandedFruitID = fruit.id
            }
        case .price:
            return
        }

        dataSource.apply(snapshot, animatingDifferences: false)
    }
}

// Delegate

extension HomeViewController {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        updateDataSource(indexPath)
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

//Prefetch

extension HomeViewController {

    func tableView(_ tableView: UITableView, prefetchRowsAt indexPaths: [IndexPath]) {

        for indexPath in indexPaths {

            guard let item = dataSource.itemIdentifier(for: indexPath),
                  case .fruit(let fruit) = item else { continue }
            fetchImage(from: fruit.imageURL){ _ in
                
            }
        }
    }
}

// Fetch Image

extension HomeViewController {
    
    func fetchImage(from url: URL, completion: @escaping (UIImage?)-> Void) {
        
       if let cachedImage = imageCache[url] {
           completion(cachedImage)
           return
       }
        
        let task = URLSession.shared.downloadTask(with: url){ [weak self] localURL, _, error in
            
            if let error = error{
                print("Error: \(error.localizedDescription)")
                return
            }
            do{
                guard let localURL = localURL else { return }
                let data = try Data(contentsOf: localURL)
                let image = UIImage(data: data)
                DispatchQueue.main.async {
                    self?.imageCache[url] = image
                    completion(image)
                }
            }
            catch{
                print(error.localizedDescription)
            }
        }
        task.resume()
    }
}

