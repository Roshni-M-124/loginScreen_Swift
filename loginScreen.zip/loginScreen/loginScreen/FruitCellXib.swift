//
//  FruitCellXib.swift
//  loginScreen
//
//  Created by Mobicip on 15/05/26.
//

import UIKit

class FruitCellXib: UITableViewCell {
    
    static let identifier = "FruitCellXib"

    @IBOutlet weak var arrowImage: UIImageView!
    @IBOutlet weak var fruitLabel: UILabel!
    @IBOutlet weak var fruitImage: UIImageView!
    var currentImageURL : URL?
    
   static func nib() -> UINib {
        return UINib(nibName:"FruitCellXib" , bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        fruitImage.contentMode = .scaleAspectFit
        fruitImage.clipsToBounds = true
        fruitLabel.numberOfLines = 0
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(title: String, image: UIImage?){
        fruitImage.image = image
        fruitLabel.text = title
        arrowImage.image = UIImage(systemName: "chevron.down")
    }
    
}
