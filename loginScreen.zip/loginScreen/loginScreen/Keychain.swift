//
//  Keychain.swift
//  loginScreen
//
//  Created by Mobicip on 14/05/26.
//

import Foundation
import Security

class Keychain {

    static let shared = Keychain()

    private let service = "com.loginScreen.auth"

    func save(email: String, password: String) {

        deleteCredentials()

        let passwordData = password.data(using: .utf8)!

        let query: [String: Any] = [

            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: email,
            kSecValueData as String: passwordData,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]

        let status = SecItemAdd(query as CFDictionary, nil)

        if status != errSecSuccess {
            print("Save failed")
        }
    }

    func getCredentials() -> (email: String, password: String)? {

        let query: [String: Any] = [

            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecReturnAttributes as String: true,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var item: CFTypeRef?

        let status = SecItemCopyMatching(query as CFDictionary, &item)

        guard status == errSecSuccess else { return nil }

        guard let result = item as? [String: Any] else { return nil}

        guard let email = result[kSecAttrAccount as String] as? String,
              let passwordData = result[kSecValueData as String] as? Data,
              let password = String(data: passwordData, encoding: .utf8)
        else { return nil }

        return (email, password)
    }

    func deleteCredentials() {

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service
        ]
        
        SecItemDelete(query as CFDictionary)
    }
}
