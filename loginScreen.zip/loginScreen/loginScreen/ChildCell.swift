//
//  ChildCell.swift
//  loginScreen
//
//  Created by Mobicip on 27/05/26.
//

import UIKit

class ChildCell: UITableViewCell {

    static let identifier: String = "ChildCell"
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var childImageView: UIImageView!
    var currentImageURL : URL?
    
    static func nib() -> UINib {
        return UINib(nibName:"ChildCell" , bundle: nil)
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        childImageView.contentMode = .scaleAspectFit
        childImageView.clipsToBounds = true
        nameLabel.numberOfLines = 0
        ageLabel.numberOfLines = 0
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func configure(name: String, age:Int, image: UIImage?){
        childImageView.image = (image != nil) ? image : UIImage(systemName: "person.crop.circle")
        nameLabel.text = "Name: \(name)"
        ageLabel.text = "Age: \(age)"
    }
}
