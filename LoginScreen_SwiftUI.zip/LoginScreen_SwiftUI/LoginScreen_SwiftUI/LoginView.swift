//
//  LoginView.swift
//  LoginScreen_SwiftUI
//
//  Created by Mobicip on 28/05/26.
//

import SwiftUI

struct LoginView: View {
    
    enum Field: Hashable{
        case email
        case passwordVisible
        case passwordHidden
    }
    
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isPasswordVisible: Bool = false
    @State private var navigateToHome: Bool = false
    @State private var isLoading: Bool = false
    @State private var childArray: [Child] = []
    
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""
    @FocusState private var focusedTextField: Field?
    
    private var isLoginDisabled: Bool {
        email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
        password.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    var body: some View {
        NavigationStack {
            GeometryReader{ geometry in
                let screenWidth = min(geometry.size.width * 0.5, 450)
                let topSpacing = min(max(geometry.size.height * 0.08, 40), 60)
                let textFieldSpacing = geometry.size.height * 0.03
                let sectionSpacing = min(max(geometry.size.height * 0.1, 20), 80)
                
                ScrollView {
                    VStack(alignment: .center, spacing: sectionSpacing){
                        Text("Welcome to Mobicip")
                            .font(.title2.weight(.semibold))
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.loginBlue)
                            .padding(.top, topSpacing)
                        
                        VStack(alignment:.leading){
                            
                            Text("Enter Email")
                                .font(.footnote)
                                .foregroundStyle(.black)
                            
                            TextField("Email",text: $email)
                                .focused($focusedTextField, equals: .email)
                                .submitLabel(.next)
                                .onSubmit {
                                    focusedTextField = .passwordVisible
                                }
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled(true)
                                .frame(height: 50)
                                .padding(.horizontal,20)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.gray.opacity(0.4),style: StrokeStyle(lineWidth: 1))
                                )
                                .padding(.bottom, textFieldSpacing)
                            
                            Text("Enter Password")
                                .font(.footnote)
                                .foregroundStyle(.black)
                            
                            HStack{
                                ZStack{
                                    TextField("Password",text: $password)
                                        .focused($focusedTextField, equals: .passwordVisible)
                                        .opacity(isPasswordVisible ? 1 : 0)
                                    SecureField("Password", text: $password)
                                        .focused($focusedTextField, equals: .passwordHidden)
                                        .opacity(isPasswordVisible ? 0 : 1)
                                }
                                .textInputAutocapitalization(.never)
                                .submitLabel(.go)
                                .onSubmit {
                                    focusedTextField = nil
                                    Task{
                                        await loginButtonTapped()
                                    }
                                }
                                
                                Button {
                                    isPasswordVisible.toggle()
                                    focusedTextField = isPasswordVisible ? .passwordVisible : .passwordHidden
                                } label: {
                                    Image(systemName: isPasswordVisible ? "eye" : "eye.slash")
                                        .foregroundStyle(.gray)
                                }
                            }
                            .frame(height: 50)
                            .padding(.horizontal)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.gray.opacity(0.4),style:StrokeStyle(lineWidth: 1))
                            )
                            .padding(.bottom)
                            .autocorrectionDisabled(true)
                        }
                        .frame(width: screenWidth)
                        
                        Button{
                            Task{
                                await loginButtonTapped()
                            }
                        }label: {
                            ZStack(alignment: .center){
                                RoundedRectangle(cornerRadius: 25)
                                    .fill(.loginBlue)
                                    .frame(height: 60)
                                
                                Text("Login")
                                    .foregroundStyle(.white)
                                    .font(.title2)
                                    .bold()
                                
                                if isLoading{
                                    HStack{
                                        Spacer()
                                        ProgressView()
                                            .tint(.white)
                                            .padding(.trailing,16)
                                    }
                                }
                            }
                            .frame(width: screenWidth,height: 60)
                        }
                        .disabled(isLoginDisabled || isLoading)
                        .opacity(isLoginDisabled || isLoading ? 0.5 : 1)
                        .alert("Login Unsuccessful",isPresented: $showAlert){
                            Button("OK", role: .cancel){}
                        }message: {
                            Text(alertMessage)
                        }
                    }
                    .onChange(of: focusedTextField) { oldValue, newValue in
                        print(oldValue as Any, "->", newValue as Any)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        focusedTextField = nil
                    }
                    .navigationDestination(isPresented: $navigateToHome, destination: {
                        ContentView(childArray: $childArray)
                    })
                }
                .refreshable {
                    email = ""
                    password = ""
                }
            }
            .scrollDismissesKeyboard(.immediately)
        }
    }
    
    func loginButtonTapped() async{
        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedPassword = password.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedEmail.isEmpty && !trimmedPassword.isEmpty else{
            alertMessage = "Please fill in all the fields."
            showAlert = true
            return
        }
        isLoading = true
        
        let result = await LoginAPI().loginAndFetchChildren(email: trimmedEmail, password: trimmedPassword)
        
        isLoading = false
        
        switch result{
            case .success(_, let users):
                email = ""
                password = ""
                childArray = users
                navigateToHome = true
                
            case .failure(let code, let Message):
                email = ""
                password = ""
                alertMessage = "\(code): \(Message)"
                showAlert = true
        }
    }
}

#Preview {
    LoginView()
}
