//
//  LoginView.swift
//  LoginScreen_SwiftUI
//
//  Created by Mobicip on 28/05/26.
//

import SwiftUI

struct LoginView: View {
    
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var navigateToHome: Bool = false
    @State private var childArray: [String] = ["1","2","3"]
    
    private var isLoginDisabled: Bool {
            email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
            password.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
    
    var body: some View {
        NavigationStack {
            VStack(alignment: .center){
                Text("Welcome to Mobicip")
                    .fontWeight(.semibold)
                    .font(.title2)
                    .foregroundStyle(.loginBlue)
                
                Spacer()
                
                VStack(alignment:.leading){
                    
                    Text("Enter Email")
                        .foregroundStyle(.black)
                    
                    TextField("Email",text: $email)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                        .autocorrectionDisabled(true)
                        .frame(width: 200,height: 50)
                        .padding(.horizontal)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray.opacity(0.4),style: StrokeStyle(lineWidth: 1))
                        )
                        .padding(.bottom)
                    
                    Text("Enter Password")
                        .foregroundStyle(.black)
                    
                    TextField("Password",text: $password)
                        .frame(width: 200,height: 50)
                        .padding(.horizontal)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray.opacity(0.4),style:StrokeStyle(lineWidth: 1))
                        )
                        .padding(.bottom, 50)
                        .autocorrectionDisabled(true)
                }
                
                Button("Login"){
                    loginButtonTapped()
                }
                .frame(width: 200, height: 50)
                .padding(.horizontal)
                .background(
                    RoundedRectangle(cornerRadius: 25)
                        .fill(.loginBlue)
                )
                .foregroundStyle(.white)
                .font(.title2)
                .bold()
                .disabled(isLoginDisabled)
                .opacity(isLoginDisabled ? 0.5 : 1)
                
                
                Spacer()
            }
            .padding(.top,40)
            .navigationDestination(isPresented: $navigateToHome, destination: {
                ContentView(childArray: $childArray)
            })
        }
    }
    
    func loginButtonTapped(){
        navigateToHome = true
    }
}

#Preview {
    LoginView()
}
