//
//  LoginView.swift
//  LoginScreen_SwiftUI
//
//  Created by Mobicip on 28/05/26.
//

import SwiftUI

struct LoginView: View {
    
    enum TextFields: Hashable{
        case email
        case password
    }
    
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isPasswordVisible: Bool = false
    @State private var navigateToHome: Bool = false
    @State private var isLoading: Bool = false
    @State private var childArray: [Child] = []
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""
    @FocusState private var focusedTextField: TextFields?
    
    private var isLoginDisabled: Bool {
        email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
        password.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    var body: some View {
        NavigationStack {
            VStack(alignment: .center){
                Text("Welcome to Mobicip")
                    .fontWeight(.semibold)
                    .font(.title2)
                    .foregroundStyle(.loginBlue)
                
                if isLoading{
                    ProgressView()
                        .tint(.gray)
                        .padding(.top,10)
                }
                
                Spacer()
                
                VStack(alignment:.leading){
                    
                    Text("Enter Email")
                        .foregroundStyle(.black)
                    
                    TextField("Email",text: $email)
                        .focused($focusedTextField, equals: .email)
                        .onSubmit {
                            focusedTextField = .password
                        }
                        .submitLabel(.next)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                        .autocorrectionDisabled(true)
                        .frame(width: 200,height: 50)
                        .padding(.horizontal)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray.opacity(0.4),style: StrokeStyle(lineWidth: 1))
                        )
                        .padding(.bottom)
                    
                    Text("Enter Password")
                        .foregroundStyle(.black)
                    
                    HStack{
                        if isPasswordVisible{
                            TextField("Password",text: $password)
                                .focused($focusedTextField, equals: .password)
                        }else{
                            SecureField("Password", text: $password)
                                .focused($focusedTextField, equals: .password)
                        }
                        Button {
                            isPasswordVisible.toggle()
                        } label: {
                            Image(systemName: isPasswordVisible ? "eye" : "eye.slash")
                                .foregroundStyle(.gray)
                                .padding(.trailing, 4)
                        }
                    }
                        .submitLabel(.go)
                        .frame(width: 200,height: 50)
                        .padding(.horizontal)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray.opacity(0.4),style:StrokeStyle(lineWidth: 1))
                        )
                        .padding(.bottom, 50)
                        .autocorrectionDisabled(true)
                }
                
                Button("Login"){
                    Task{
                        await loginButtonTapped()
                    }
                }
                .frame(width: 200, height: 50)
                .padding(.horizontal)
                .background(
                    RoundedRectangle(cornerRadius: 25)
                        .fill(.loginBlue)
                )
                .foregroundStyle(.white)
                .font(.title2)
                .bold()
                .disabled(isLoginDisabled || isLoading)
                .opacity(isLoginDisabled || isLoading ? 0.5 : 1)
                .alert("Login Unsuccessful",isPresented: $showAlert){
                    Button("OK", role: .cancel){}
                }message: {
                    Text(alertMessage)
                }
                
                Spacer()
            }
            .padding(.top,40)
            .navigationDestination(isPresented: $navigateToHome, destination: {
                ContentView(childArray: $childArray)
            })
        }
        .onAppear{
            focusedTextField = .email
        }
    }
    
    func loginButtonTapped() async{
        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedPassword = password.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedEmail.isEmpty && !trimmedPassword.isEmpty else{
            alertMessage = "Please fill in all the fields."
            showAlert = true
            return
        }
        isLoading = true
        
        let result = await LoginAPI().loginAndFetchChildren(email: trimmedEmail, password: trimmedPassword)
        
        isLoading = false
        
        switch result{
            case .success(_, let users):
                email = ""
                password = ""
                childArray = users
                navigateToHome = true
                
            case .failure(let code, let Message):
                email = ""
                password = ""
                alertMessage = "\(code): \(Message)"
                showAlert = true
        }
    }
}

#Preview {
    LoginView()
}
