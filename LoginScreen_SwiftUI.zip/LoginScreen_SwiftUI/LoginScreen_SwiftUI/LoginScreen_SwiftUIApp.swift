//
//  LoginScreen_SwiftUIApp.swift
//  LoginScreen_SwiftUI
//
//  Created by Mobicip on 28/05/26.
//

import SwiftUI

@main
struct LoginScreen_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
