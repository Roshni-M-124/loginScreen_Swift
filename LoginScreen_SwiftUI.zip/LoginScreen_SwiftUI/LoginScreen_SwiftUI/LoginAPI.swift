//
//  LoginAPI.swift
//  LoginScreen_SwiftUI
//
//  Created by Mobicip on 29/05/26.
//

import Foundation
import CryptoKit

enum LoginResult{
    case success(message:String, users: [Child])
    case failure(code: String, message: String)
}

struct Response: Decodable{
    let mwsResponse: MWSContent
}

struct MWSContent: Decodable{
    let managed_users: [Child]?
    let status: ResponseStatus
}

struct ResponseStatus: Decodable{
    let code: String
    let message: String
}

struct Child: Decodable,Hashable{
    var id: String {name}
    let name: String
    let age: Int
    let thumbnail: String?
}

class LoginAPI{
    
    let clientKey = "eQmqIhqfIeNs0OX6avY5YpauB"
    let token = "NO-TOKEN"
    
    let apiDetails: [String: Any] = ["version": "2.3","app_version": "7.0"]
    
    let clientDetails: [String: Any] = ["version": "2.2", "identity": "21V21B337GMX2", "session_hash": "de951cc9-0a2e-41fd-918d-b2f55c09d780"]
    
    func loginAndFetchChildren(email: String, password: String) async -> LoginResult {
        
        let userDetails: [String: Any] = [
            "timezone": "Asia/Kolkata",
            "email": email,
            "password": hashMD5(password)
        ]
        
        let sessionDetails: [String: Any] = ["token": token]
        
        let requestBody: [String: Any] = [
            "api": apiDetails,
            "Client": clientDetails,
            "User": userDetails,
            "Session": sessionDetails
        ]
        
        let innerPayload: [String:Any] = ["Request": requestBody]
        
        guard let innerjsonData = try? JSONSerialization.data(withJSONObject: innerPayload, options: .withoutEscapingSlashes),
              let innerRequestString = String(data: innerjsonData, encoding: .utf8) else{
            return .failure(code: "", message: "Failed to format inner request payload")
        }
        
        let checksum = generateChecksum(innerString: innerRequestString)
        
        let finalRequest: [String: Any] = [
            "mwsRequest": [
                "String": innerPayload,
                "Checksum": checksum
            ]
        ]
        
        guard let finalJsonData = try? JSONSerialization.data(withJSONObject: finalRequest),
              let url = URL(string: "https://webd.prgr.in/api/v2/login")else{
            return .failure(code: "", message: "Invalid URL or malformed data payload")
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.httpBody = finalJsonData
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
                
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                    return .failure(code: "", message: "Server connection failed")
            }
                    
            let decodedResponse = try JSONDecoder().decode(Response.self, from: data)
            let mwsResponse = decodedResponse.mwsResponse
                    
            if mwsResponse.status.code == "000" {
                return .success(message: mwsResponse.status.message, users: mwsResponse.managed_users ?? [])
            } else {
                return .failure(code: mwsResponse.status.code, message: mwsResponse.status.message)
            }
                    
        } catch {
            return .failure(code: "", message: error.localizedDescription)
        }
    }
    
    private func generateChecksum(innerString: String) -> String {
        let hmacInput = token + innerString + clientKey
        let hmacKey = SymmetricKey(data: Data(token.utf8))
        let signature = HMAC<SHA256>.authenticationCode(for: Data(hmacInput.utf8), using: hmacKey)
        return signature.map { String(format: "%02x", $0) }.joined()
    }
        
    private func hashMD5(_ string: String) -> String {
        guard let data = string.data(using: .utf8) else { return "" }
        let digest = Insecure.MD5.hash(data: data)
        return digest.map { String(format: "%02hhx", $0) }.joined()
    }
}
