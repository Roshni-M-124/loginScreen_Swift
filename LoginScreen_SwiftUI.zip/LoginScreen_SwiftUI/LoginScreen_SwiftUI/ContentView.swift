//
//  ContentView.swift
//  LoginScreen_SwiftUI
//
//  Created by Mobicip on 28/05/26.
//

import SwiftUI

struct ContentView: View {
    
    @Binding var childArray: [Child]
    
    var body: some View {
            List {
                ForEach(childArray , id: \.id){ child in
                    HStack(){
                        ChildThumbnailView(urlString: child.thumbnail)
                            .frame(width: 50,height: 50)
                            .padding(.trailing,20)
                        
                        VStack(alignment:.leading){
                            Text("Name: \(child.name)")
                            Text("Age: \(child.age)")
                        }
                        .font(.headline)
                        Spacer()
                    }
                    .padding(.bottom,5)
                }
            }
            .navigationTitle("Managed Users")
    }
}

struct ChildThumbnailView: View{
    let urlString: String?
    
    var defaultPlaceHolder: some View{
        Image(systemName: "person.circle.fill")
            .resizable()
            .scaledToFit()
    }
    
    var body: some View{
        if let urlString,!urlString.isEmpty, urlString != "<null>", let url = URL(string: urlString){
            
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()

                case .failure(_):
                    defaultPlaceHolder

                case .empty:
                    defaultPlaceHolder

                @unknown default:
                    defaultPlaceHolder
                }
            }
        }
        else{
            defaultPlaceHolder
        }
    }
}

#Preview {
    
}

