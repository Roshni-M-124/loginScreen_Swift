//
//  ContentView.swift
//  LoginScreen_SwiftUI
//
//  Created by Mobicip on 28/05/26.
//

import SwiftUI

struct ContentView: View {
    
    @Binding var childArray: [String]
    
    var body: some View {
            List {
                ForEach(childArray, id: \.self){ child in
                    HStack(){
                        Image(systemName: "person.crop.circle")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .padding(.trailing,20)
                        
                        VStack(alignment:.leading){
                            Text("Name: \(child)")
                            Text("Age: \(child)")
                        }
                        .font(.headline)
                        Spacer()
                    }
                    .padding(.bottom,5)
                }
            }
            .navigationTitle("Managed Users")
    }
}


#Preview {
    
}

